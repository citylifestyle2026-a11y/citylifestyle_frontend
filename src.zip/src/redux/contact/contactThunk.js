import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  createContactApi,
  getAllContactsApi,
  exportContactsApi,
  getContactByIdApi,
  updateContactApi,
  deleteContactApi,
  getUniqueReferencesApi,
  getUniqueAreasApi,
  getReferenceSummaryApi,
  bulkUpdateContactStatusApi,
  sendContactPassApi,
} from "../../services/contactService";
import { getApiErrorMessage } from "../../utilits/apiError";
import { saveBlob, XLSX_MIME } from "../../utilits/download";

// ================= CREATE CONTACT =================
export const createContact = createAsyncThunk(
  "contact/createContact",
  async (data, thunkAPI) => {
    try {
      return await createContactApi(data);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to create contact")
      );
    }
  }
);

// ================= GET ALL CONTACTS =================
export const getAllContacts = createAsyncThunk(
  "contact/getAllContacts",
  async (params, thunkAPI) => {
    try {
      return await getAllContactsApi(params);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to fetch contacts")
      );
    }
  }
);

// ================= EXPORT CONTACTS =================
// params passed in are the page's CURRENT search/sortBy/sortOrder/
// companyCategory/reference filters (same params getAllContacts
// already uses), so the exported file always matches exactly what the
// Contact List table is showing at the moment Export is clicked.
export const exportContacts = createAsyncThunk(
  "contact/exportContacts",
  async (params, thunkAPI) => {
    try {
      const response = await exportContactsApi(params);

      saveBlob(
        new Blob([response.data], { type: XLSX_MIME }),
        `ContactList_${Date.now()}.xlsx`
      );

      return true;
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to export contacts")
      );
    }
  }
);

// ================= GET CONTACT BY ID =================
export const getContactById = createAsyncThunk(
  "contact/getContactById",
  async (id, thunkAPI) => {
    try {
      return await getContactByIdApi(id);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to fetch contact")
      );
    }
  }
);

// ================= UPDATE CONTACT =================
export const updateContact = createAsyncThunk(
  "contact/updateContact",
  async ({ id, data }, thunkAPI) => {
    try {
      return await updateContactApi(id, data);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to update contact")
      );
    }
  }
);

// ================= DELETE CONTACT =================
export const deleteContact = createAsyncThunk(
  "contact/deleteContact",
  async (id, thunkAPI) => {
    try {
      return await deleteContactApi(id);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to delete contact")
      );
    }
  }
);

// ================= GET UNIQUE AREAS =================
export const getUniqueAreas = createAsyncThunk(
  "contact/getUniqueAreas",
  async (_, thunkAPI) => {
    try {
      return await getUniqueAreasApi();
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to fetch areas")
      );
    }
  }
);

// ================= GET UNIQUE REFERENCES =================
export const getUniqueReferences = createAsyncThunk(
  "contact/getUniqueReferences",
  async (params, thunkAPI) => {
    try {
      return await getUniqueReferencesApi(params);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to fetch unique references")
      );
    }
  }
);

// ================= GET REFERENCE SUMMARY (GROUPED) =================
// Powers the "Reference Summary" section shown below the Contact List
// table — kept as its own thunk (separate from getUniqueReferences,
// which only feeds the filter dropdown's flat value list) since the
// grouped { reference, contactNames } shape is a different concern.
export const getReferenceSummary = createAsyncThunk(
  "contact/getReferenceSummary",
  async (_, thunkAPI) => {
    try {
      return await getReferenceSummaryApi();
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to fetch reference summary")
      );
    }
  }
);

// ================= BULK APPROVAL STATUS =================
export const bulkUpdateContactStatus = createAsyncThunk(
  "contact/bulkUpdateContactStatus",
  async (data, thunkAPI) => {
    try {
      return await bulkUpdateContactStatusApi(data);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to update contact status")
      );
    }
  }
);

// ================= SEND PASS (WHATSAPP) =================
export const sendContactPass = createAsyncThunk(
  "contact/sendContactPass",
  async (data, thunkAPI) => {
    try {
      return await sendContactPassApi(data);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        getApiErrorMessage(error, "Failed to send pass")
      );
    }
  }
);
