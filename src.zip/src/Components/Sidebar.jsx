import { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';

import {
  MdDashboard,
  MdClose,
  MdKeyboardArrowDown,
} from 'react-icons/md';

import { FaUsers, FaIdBadge, FaAddressBook, FaUserFriends, FaEnvelopeOpenText, FaLink, FaBan } from 'react-icons/fa';

import {
  BsCalendarEventFill,
  BsFillTicketFill,
} from 'react-icons/bs';

import { FaFlag } from 'react-icons/fa6';

import '../assets/CSS/Sidebar.css';
// Same logo file as the Login page.
import cityLifestyleLogo from '../assets/images/logo/city-lifestyle-logo.jpg';

const menuItems = [
  {
    label: 'Dashboard',
    icon: <MdDashboard />,
    path: '/dashboard',
  },
 
  {
    label: 'Add Event',
    icon: <BsCalendarEventFill />,
    path: '/event',
  },
  {
    label: 'Contact Book',
    icon: <FaUserFriends />,
    path: '/contact-book',
  },
   {
    label: 'Guest List',
    icon: <FaAddressBook />,
    submenu: [
      // Admin Guest List lives at /gust-list — '/contact' is the
      // PUBLIC marketing contact page (see App.jsx) and must stay that
      // way.
      { label: 'Guest List', path: '/gust-list' },
      { label: 'Company Category', path: '/company-categories' },
      // Edition master data — feeds the Edition checkboxes on the Event
      // History page below (see models/contactEventHistory.model.js).
      // { label: 'Editions', path: '/editions' },
      // Event History is its own standalone page — "Add Details" picks
      // the Contact itself from a dropdown inside the modal.
      { label: 'Event History', path: '/event-history' },
    ],
  },
  {
    label: 'Form Links',
    icon: <FaLink />,
    path: '/form-links',
  },
  {
    label: 'Ghost List',
    icon: <FaBan />,
    path: '/ghost-list',
  },
  {
    label: 'Invitation Cards',
    icon: <FaEnvelopeOpenText />,
    submenu: [
      // WhatsApp invitation cards (name only).
      { label: 'Invitation Cards', path: '/invite-cards' },
      // Guest card link design (guest adds own photo + name).
      { label: 'Guest Card', path: '/guest-card-design' },
    ],
  },
  {
    label: 'Entry Report',
    icon: <FaFlag />,
    path: '/entry-report',
  },
   {
    label: 'User Management',
    icon: <FaUsers />,
    submenu: [
      { label: 'Users', path: '/user' },
      { label: 'Roles', path: '/role' },
      // { label: 'Permissions', path: '/permission' },
      { label: 'Admins', path: '/admin' },
    ],
  },
  {
    label: 'Manual Booking',
    icon: <BsFillTicketFill />,
    path: '/booking',
  },
    {
    label: 'Crew',
    icon: <FaIdBadge />,
    submenu: [
      { label: 'Crew List', path: '/crew' },
      { label: 'Crew Category', path: '/crew-categories' },
    ],
  },
];

export default function Sidebar() {
  const location = useLocation();

  // Current user/role/permissions — prefer the live profile (from
  // getProfile()), fall back to the user cached at login (available
  // immediately on refresh, before getProfile() resolves).
  //
  // IMPORTANT: role/permissions are resolved field-by-field, not by
  // picking `profile` OR `authUser` wholesale. `/auth/profile` serves
  // Admin and Checker/User from two different backend models — if that
  // response ever omits or differently-shapes `role`/`permissions` for
  // one of them, an all-or-nothing `profile || authUser` would silently
  // lose a value that `authUser` (set correctly at login) still has,
  // e.g. right after getProfile() resolves. Falling back per-field means
  // a gap in one response can't blank out a value the other already has.
  const profile = useSelector((state) => state.auth.profile);
  const authUser = useSelector((state) => state.auth.user);
  const role = profile?.role ?? authUser?.role;
  const userPermissions = Array.isArray(profile?.permissions)
    ? profile.permissions
    : Array.isArray(authUser?.permissions)
    ? authUser.permissions
    : [];

  const hasPermission = (permission) =>
    role === 'admin' || userPermissions.includes(permission);

  // Checker is locked to Entry Report ONLY — Dashboard, Event, Booking,
  // User Management (Users/Roles), and any future module are all hidden
  // for this role, regardless of what's added to `menuItems` later.
  const isChecker = role === 'checker';

  // Admin (the only remaining role besides Checker) keeps the existing
  // behavior unchanged, including the Entry Report permission gate below.
  const visibleMenuItems = menuItems.filter((item) => {
    if (isChecker) {
      return item.label === 'Entry Report' && hasPermission('Entry Report');
    }

    if (item.label === 'Entry Report') {
      return hasPermission('Entry Report');
    }

    // The Block List page (shown as "Ghost List" in the menu) is for Admin accounts only.
    // Matched by path, not by label.
    if (item.path === '/ghost-list') {
      return role === 'admin';
    }

    return true;
  });

  const [isOpen, setIsOpen] = useState(false);
  // Label of the submenu that contains the current page (if any).
  const activeSubmenuLabel =
    visibleMenuItems.find((item) =>
      item.submenu?.some((sub) => location.pathname === sub.path)
    )?.label || null;

  // Starts open for the current page's menu, but it is plain user-controlled
  // state afterwards - so clicking the menu again closes it, even while one
  // of its pages is open.
  const [expandedMenu, setExpandedMenu] = useState(activeSubmenuLabel);

  // Opening a page from another menu (or via a link) opens its parent menu.
  useEffect(() => {
    if (activeSubmenuLabel) setExpandedMenu(activeSubmenuLabel);
  }, [location.pathname]); // eslint-disable-line react-hooks/exhaustive-deps

  const closeSidebar = () => setIsOpen(false);

  const toggleSubmenu = (label) => {
    setExpandedMenu((prev) => (prev === label ? null : label));
  };

  // Toggle sidebar from header button
  useEffect(() => {
    const handleToggle = () => setIsOpen((prev) => !prev);

    window.addEventListener('toggle-sidebar', handleToggle);

    return () => {
      window.removeEventListener('toggle-sidebar', handleToggle);
    };
  }, []);

  // Close on ESC
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        closeSidebar();
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // Prevent body scroll when sidebar open
  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  return (
    <>
      {/* Overlay */}
      <div
        className={`overlay ${isOpen ? 'visible' : ''}`}
        onClick={closeSidebar}
      />

      {/* Sidebar */}
      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        {/* Header */}
        <div className='sidebarHeader'>
          <div className='logoWrap'>
            <img
              src={cityLifestyleLogo}
              alt='City Lifestyle'
              className='logoIcon'
            />
            <div className='logoText'>
              <span className='logoShubh'>City</span>
              <span className='logoHindi'>LifeStyle</span>
            </div>
          </div>

          <button
            type='button'
            className='closeButton'
            onClick={closeSidebar}
            aria-label='Close sidebar'
          >
            <MdClose />
          </button>
        </div>

        {/* Navigation */}
        <nav className='nav'>
          {visibleMenuItems.map((item) => {
            // =========================
            // SUBMENU ITEM
            // =========================
            if (item.submenu) {
              // Open / closed is controlled only by expandedMenu (set on
              // click, and to the current page's menu on navigation).
              const isExpanded = expandedMenu === item.label;

              return (
                <div key={item.label}>
                  <button
                    type='button'
                    className='navItem'
                    onClick={() => toggleSubmenu(item.label)}
                  >
                    <span className='icon'>{item.icon}</span>
                    <span className='label'>{item.label}</span>

                    <span
                      className={`chevron ${
                        isExpanded ? 'rotated' : ''
                      }`}
                    >
                      <MdKeyboardArrowDown />
                    </span>
                  </button>

                  {/* Submenu */}
                  <div
                    className={`submenuWrapper ${
                      isExpanded ? 'expanded' : ''
                    }`}
                  >
                    <div className='submenuInner'>
                      <div className='submenu'>
                        {item.submenu.map((subItem) => (
                          <NavLink
                            key={subItem.label}
                            to={subItem.path}
                            className={({ isActive }) =>
                              `submenuItem ${isActive ? 'active' : ''}`
                            }
                            onClick={closeSidebar}
                          >
                            <span className='submenuDash'>-</span>
                            <span>{subItem.label}</span>
                          </NavLink>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            }

            // =========================
            // NORMAL MENU ITEM
            // =========================
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `navItem ${isActive ? 'active' : ''}`
                }
                onClick={closeSidebar}
              >
                <span className='icon'>{item.icon}</span>
                <span className='label'>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </aside>
    </>
  );
} 