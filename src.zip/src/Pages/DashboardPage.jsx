import { useEffect, useMemo, useCallback } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import Sidebar from "../Components/Sidebar";
import Header from "../Components/Header";
import DashboardCard from "../Components/DashboardCard";
import { useGlobalEvent } from "../context/EventContext";
import { getDashboardSummary } from "../redux/dashboard/dashboardThunk";
import { clearDashboardState } from "../redux/dashboard/dashboardSlice";
import '../assets/CSS/DashboardPage.css';
import '../assets/CSS/DashboardResponsive.css';

export default function DashboardPage() {
  const dispatch = useDispatch();
  const { dashboardData, loading, error } = useSelector((state) => state.dashboard);
  // "" = default (currently active event, or the most recently expired
  // one if nothing is running — resolved server-side). Any other value
  // is a specific event id, active or inactive/expired, chosen by the
  // admin — its own data is shown on its own, never combined with any
  // other event's numbers.
  // The event comes from the dropdown in the header (same on every page).
  const { selectedEventId } = useGlobalEvent();

  // Applies immediately on selection — no separate "Search"/"Apply"
  // step needed to see the chosen event's dashboard data.
  useEffect(() => {
    dispatch(getDashboardSummary(selectedEventId || undefined));
  }, [dispatch, selectedEventId]);

  useEffect(() => {
    return () => {
      dispatch(clearDashboardState());
    };
  }, [dispatch]);

  const handleRetry = useCallback(() => {
    dispatch(clearDashboardState());
    dispatch(getDashboardSummary(selectedEventId || undefined));
  }, [dispatch, selectedEventId]);

  const activeEvent = dashboardData?.activeEvent;
  const activeEventEndDateTime = activeEvent?.endDateTime;

  // Auto-refetch once the active event's own endDateTime is reached, so
  // Active -> Inactive/Expired shows up without a manual refresh.
  //
  // Single, self-contained effect — no separate hook file, no
  // ref-wrapped callback. `dispatch` from useDispatch() is already
  // referentially stable, so there's nothing here that needs a ref to
  // stay fresh; the only dependency that matters is the event's own
  // end time.
  useEffect(() => {
    if (!activeEventEndDateTime) return;

    const endTime = new Date(activeEventEndDateTime).getTime();
    if (Number.isNaN(endTime)) return;

    let hasFired = false;
    const refetch = () => {
      if (hasFired) return;
      hasFired = true;
      dispatch(getDashboardSummary(selectedEventId || undefined));
    };

    const msRemaining = endTime - Date.now();

    if (msRemaining <= 0) {
      // Already past expiry by the time this effect ran (e.g. the tab
      // was backgrounded through the expiry moment) — refetch now.
      refetch();
      return;
    }

    // setTimeout's delay is stored as a 32-bit signed int; anything
    // past ~24.8 days overflows and fires almost immediately. Clamping
    // means a far-future endDateTime schedules a safe recheck instead.
    const MAX_TIMEOUT_MS = 2147483647;
    const timerId = window.setTimeout(
      refetch,
      Math.min(msRemaining, MAX_TIMEOUT_MS)
    );

    // Fallback: if the tab was backgrounded and the timer's actual fire
    // time drifted (browsers throttle timers in inactive tabs), catch
    // up as soon as the tab becomes visible again.
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible" && Date.now() >= endTime) {
        refetch();
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      window.clearTimeout(timerId);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [activeEventEndDateTime, dispatch, selectedEventId]);

  const eventDateRange = useMemo(() => {
    if (!activeEvent?.startDateTime || !activeEvent?.endDateTime) return "";
    const fmt = (d) =>
      new Date(d).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
    return `${fmt(activeEvent.startDateTime)} - ${fmt(activeEvent.endDateTime)}`;
  }, [activeEvent?.startDateTime, activeEvent?.endDateTime]);

  // The dashboard now shows only two sections - Booking and Entry Report -
  // fed by dashboard.service.js's getDashboardCounts(). Every tile is a
  // single number, so each renders as amount-only (hideBody: true).
  // `infoText` is the plain-language explanation of the "i" button.
  const bookingCards = useMemo(
    () => [
      {
        key: "totalBookings",
        title: "Total Bookings",
        amountValue: String(dashboardData?.totalBookings ?? 0),
        infoText:
          "Total number of tickets booked for this event (sum of the quantity of every booking). Deleted and cancelled bookings (including cancelled passes) are not counted.",
      },
    ],
    [dashboardData]
  );

  // Quantity-wise bookings: one card per quantity that really exists in the
  // data (1 Qty, 2 Qty, 3 Qty ...). The list comes from the backend, so a
  // booking made with a brand-new quantity gets its own card automatically.
  const quantityCards = useMemo(
    () =>
      (dashboardData?.quantityWiseBookings || []).map((item) => ({
        key: `qty-${item.quantity}`,
        title: `${item.quantity} Qty`,
        amountValue: String(item.bookings),
        infoText: `Bookings made with quantity ${item.quantity} (${item.bookings} booking${item.bookings === 1 ? "" : "s"} x ${item.quantity} = ${item.tickets} ticket${item.tickets === 1 ? "" : "s"}). Deleted, cancelled and crew bookings are not counted.`,
      })),
    [dashboardData]
  );

  const entryCards = useMemo(
    () => [
      {
        key: "scannedEntries",
        title: "Checked In",
        amountValue: String(dashboardData?.scannedEntries ?? 0),
        infoText:
          "Guests whose pass was scanned at the gate - they have arrived at the event. Deleted bookings are not counted.",
      },
      {
        key: "registeredNotScanned",
        title: "Not Checked In",
        amountValue: String(dashboardData?.registeredNotScanned ?? 0),
        infoText:
          "Guests who have a pass (sent or registered) but have not been scanned at the gate yet. Cancelled or deleted passes are not counted.",
      },
    ],
    [dashboardData]
  );

  // Attendance reminder answers (WhatsApp Yes / No buttons) for this event.
  // "No response" = reminder sent but the guest has not tapped anything yet;
  // it changes to Yes / No by itself when they do.
  const attendanceCards = useMemo(
    () => [
      {
        key: "rsvpYes",
        title: "Attending (Yes)",
        amountValue: String(dashboardData?.rsvp?.yes ?? 0),
        infoText:
          "Guests who tapped Yes on the attendance reminder (WhatsApp). If a guest changes their answer, the count updates automatically.",
      },
      {
        key: "rsvpNo",
        title: "Not Attending (No)",
        amountValue: String(dashboardData?.rsvp?.no ?? 0),
        infoText:
          "Guests who tapped No on the attendance reminder (WhatsApp).",
      },
      {
        key: "rsvpNoResponse",
        title: "No Response",
        amountValue: String(dashboardData?.rsvp?.noResponse ?? 0),
        infoText:
          "Guests who were sent the reminder but have not tapped Yes or No yet. When they tap, they move to Yes or No automatically.",
      },
    ],
    [dashboardData]
  );

  // Crew (event staff, not guests) - kept apart from the guest numbers above.
  const crewCards = useMemo(
    () => [
      {
        key: "crewTotal",
        title: "Total Crew",
        amountValue: String(dashboardData?.crew?.total ?? 0),
        infoText: "All crew members in the Crew list (any status). Deleted crew are not counted.",
      },
      {
        key: "crewCheckedIn",
        title: "Crew Checked In",
        amountValue: String(dashboardData?.crew?.checkedIn ?? 0),
        infoText: "Crew passes scanned at the gate for this event.",
      },
      {
        key: "crewNotCheckedIn",
        title: "Crew Not Checked In",
        amountValue: String(dashboardData?.crew?.notCheckedIn ?? 0),
        infoText: "Crew passes sent for this event that have not been scanned yet.",
      },
    ],
    [dashboardData]
  );

  const sections = [
    {
      key: "booking",
      title: "Booking",
      subtitle: "Tickets booked for this event",
      to: "/booking",
      linkLabel: "View Bookings",
      cards: bookingCards,
    },
    {
      key: "quantity",
      title: "Booking - Quantity Wise",
      subtitle: "Number of bookings for each quantity",
      to: "/booking",
      linkLabel: "View Bookings",
      cards: quantityCards,
      emptyText: "No bookings yet",
    },
    {
      key: "entry",
      title: "Entry Report",
      subtitle: "Who came in at the gate",
      to: "/entry-report",
      linkLabel: "View Entry Report",
      cards: entryCards,
    },
    {
      key: "attendance",
      title: "Attendance Confirmation",
      subtitle: `Reminders sent: ${dashboardData?.rsvp?.reminderSent ?? 0}`,
      to: "/gust-list",
      linkLabel: "View Guest List",
      cards: attendanceCards,
    },
    {
      key: "crew",
      title: "Crew",
      subtitle: "Event staff - separate from guests",
      to: "/crew",
      linkLabel: "View Crew",
      cards: crewCards,
    },
  ];

  return (
    <div className="dashboardPage appPage">
      <Sidebar />

      <div className="mainArea appMain">
        <Header />

        <div className="content appContent">
          <div className="dashboardPage-topRow">
            <div>
              <h1 className="pageDashboardTitle appPageTitle">Dashboard</h1>
              <p className="pageSubtitle" style={{ margin: 0 }}>Dashboard</p>
            </div>

          </div>

          <div className="dashboardPage-body">
            {error && (
              <div className="dashboardErrorBar">
                <span className="dashboardError">{error}</span>
                <button type="button" className="dashboardRetryBtn" onClick={handleRetry}>
                  Retry
                </button>
              </div>
            )}

            {loading && !dashboardData ? (
              <>
                <section className="eventInfoCard">
                  <div className="skeletonBlock skeletonAmount" />
                  <div className="skeletonBlock skeletonRow" style={{ marginTop: 14 }} />
                </section>
                <div className="dashSections">
                  {["booking", "quantity", "entry", "attendance", "crew"].map((k) => (
                    <section className={`dashSection dashSection--${k}`} key={k}>
                      <DashboardCardSkeleton />
                    </section>
                  ))}
                </div>
              </>
            ) : error && !dashboardData ? (
              // Request failed and there's no prior data to fall back on —
              // the error bar above already shows the message and Retry,
              // so render nothing here rather than empty-state cards that
              // would make a failure look like "no data".
              null
            ) : (
              <>
                {/* Active event — one compact card (replaces the separate
                    blue banner + the tall full-width "Active Event" table). */}
                <section className="eventInfoCard">
                  <div className="eventInfoCard__head">
                    <span className="eventInfoCard__tag">Active Event</span>
                    <h2 className="eventInfoCard__title">
                      {activeEvent?.title || "No Active Event"}
                    </h2>
                  </div>

                  {activeEvent && (
                    <dl className="eventInfoCard__grid">
                      <div className="eventInfoCard__item">
                        <dt>Venue</dt>
                        <dd>{activeEvent.venueName || "-"}</dd>
                      </div>
                      <div className="eventInfoCard__item">
                        <dt>Duration</dt>
                        <dd>{eventDateRange || "-"}</dd>
                      </div>
                      <div className="eventInfoCard__item">
                        <dt>Address</dt>
                        <dd>{activeEvent.address || "-"}</dd>
                      </div>
                    </dl>
                  )}
                </section>

                <div className="dashSections">
                  {sections.map((section) => (
                    <section
                      className={`dashSection dashSection--${section.key}`}
                      key={section.key}
                    >
                      <div className="dashSection__head">
                        <div>
                          <h2 className="dashSection__title">{section.title}</h2>
                          <p className="dashSection__sub">{section.subtitle}</p>
                        </div>
                        <Link className="dashSection__link" to={section.to}>
                          {section.linkLabel} &rarr;
                        </Link>
                      </div>

                      <div className="dashSection__cards">
                        {section.cards.length === 0 && section.emptyText && (
                          <p className="dashSection__empty">{section.emptyText}</p>
                        )}
                        {section.cards.map((card) => (
                          <DashboardCard
                            key={card.key}
                            compact
                            title={card.title}
                            amountValue={card.amountValue}
                            amountLabel={card.title}
                            hideBody
                            infoText={card.infoText}
                          />
                        ))}
                      </div>
                    </section>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* <div className="footer">
          <span>2026 © Keenthemes</span>
          <div className="footerLinks">
            <span>About</span>
            <span>Support</span>
            <span>Purchase</span>
          </div>
        </div> */}
      </div>
    </div>
  );
}

function DashboardCardSkeleton() {
  return (
    <div className="card card--compact cardSkeleton">
      <div className="skeletonBlock skeletonAmount" />
      <div className="skeletonBlock skeletonRow" style={{ marginBottom: 0 }} />
    </div>
  );
}